
x=5

def get_lis(this):
	lis=this[0]
	for x in range(len(this[1])):
		lis=lis[this[1][x]]
	return lis
pos=[""]*2
pos[0]=1
pos[1]=[1,[pos,[0]]]



for y in range(10):
	pos[0]=pos[0]+1
	#print(pos[0])
	#print(pos[1][1])
	print(get(pos[1][1]))


points=[""]*12


points[0]=[""]*7
points[0][0]=[1]
points[0][1]=[0,0,0,[0.5,0,0,0],pos_dis1_F]#wholething_and_goes_to_and_replaced_by_expledis_f
points[0][2]=[0,0,0]
points[0][3]=[0,0,0]
points[0][4]=[1,[1,1],mut_F]#gives and sends the whole thing back 
conectionlist.append([0,1,[1,1,points],coler_F,[0.01,2],scailcon_F])
points[0][5]=[2,[1,1],mut_F]
conectionlist.append([0,2,[1,1],coler_F,[0.01,2],scailcon_F])
points[0][6]=[3,[math.sqrt(2),1],mut_F]
conectionlist.append([0,3,[math.sqrt(2),1],coler_F,[0.01,2],scailcon_F])

points[1]=[""]*4
points[1][0]=[1]
points[1][1]=[0,1,0,[0.5,0,1,0],pos_dis1_F]#wholething_and_goes_to_and_replaced_by_expledis_f
points[1][2]=[0,0,0]
points[1][3]=[0,0,0]

points[2]=[""]*4
points[2][0]=[1]
points[2][1]=[1,0,0,[0.5,1,0,0],pos_dis1_F]#wholething_and_goes_to_and_replaced_by_expledis_f
points[2][2]=[0,0,0]
points[2][3]=[0,0,0]

points[3]=[""]*4
points[3][0]=[1]
points[3][1]=[1,1,0,[0.5,1,1,0],pos_dis1_F]#wholething_and_goes_to_and_replaced_by_expledis_f
points[3][2]=[0,0,0]
points[3][3]=[0,0,0]


points[4]=[""]*5
points[4][0]=[1]#mass
points[4][1]=[0,0,1]#pos
points[4][2]=[0,0,0]#velocity
points[4][3]=[0,0,0]#force
points[4][4]=[1,[1,1],mut_F]#to_wher,#thingthat_goes_to_force_function,force_function
#conectionlist.append([4,1,[1,1],coler_F,[0.01,2],scailcon_F])

points[5]=[""]*5
points[5][0]=[1]
points[5][1]=[0,1,1]
points[5][2]=[0,0,0]
points[5][3]=[0,0,0]
points[5][4]=[0,[1,1],mut_F]
#conectionlist.append([5,0,[1,1],coler_F,[0.01,2],scailcon_F])

points[6]=[""]*5
points[6][0]=[1]#mass
points[6][1]=[1,0,1]#pos
points[6][2]=[0,0,0]#velocity
points[6][3]=[0,0,0]#force
points[6][4]=[1,[1,1],mut_F]#to_wher,#thingthat_goes_to_force_function,force_function
#conectionlist.append([6,1,[1,1],coler_F,[0.01,2],scailcon_F])

points[7]=[""]*5
points[7][0]=[1]#mass
points[7][1]=[1,1,1]#pos
points[7][2]=[0,0,0]#velocity
points[7][3]=[0,0,0]#force
points[7][4]=[1,[1,1],mut_F]#to_wher,#thingthat_goes_to_force_function,force_function
#conectionlist.append([7,1,[1,1],coler_F,[0.01,2],scailcon_F])

points[8]=[""]*5
points[8][0]=[1]#mass
points[8][1]=[0,0,2]#pos
points[8][2]=[0,0,0]#velocity
points[8][3]=[0,0,0]#force
points[8][4]=[1,[1,1],mut_F]#to_wher,#thingthat_goes_to_force_function,force_function
#conectionlist.append([8,1,[1,1],coler_F,[0.01,2],scailcon_F])

points[9]=[""]*5
points[9][0]=[1]#mass
points[9][1]=[0,1,2]#pos
points[9][2]=[0,0,0]#velocity
points[9][3]=[0,0,0]#force
points[9][4]=[1,[1,1],mut_F]#to_wher,#thingthat_goes_to_force_function,force_function
#conectionlist.append([9,1,[1,1],coler_F,[0.01,2],scailcon_F])

points[10]=[""]*5
points[10][0]=[1]#mass
points[10][1]=[1,0,2]#pos
points[10][2]=[0,0,0]#velocity
points[10][3]=[0,0,0]#force
points[10][4]=[1,[1,1],mut_F]#to_wher,#thingthat_goes_to_force_function,force_function
#conectionlist.append([10,1,[1,1],coler_F,[0.01,2],scailcon_F])

points[11]=[""]*5
points[11][0]=[1]#mass
points[11][1]=[1,1,2]#pos
points[11][2]=[0,0,0]#velocity
points[11][3]=[0,0,0]#force
points[11][4]=[1,[1,1],mut_F]#to_wher,#thingthat_goes_to_force_function,force_function
#conectionlist.append([11,1,[1,1],coler_F,[0.01,2],scailcon_F])


points=[""]*8

#forstandard string should be [[witchpoint,string lanth,stringconsent,witchobject],mult_f]
points[0]=[""]*9
points[0][0]=[1]
points[0][1]=[0,0,0,[0.1,0,0,0],pos_dis1_F]#wholething_and_goes_to_and_replaced_by_expledis_f

points[0][2]=[0,0,0]
points[0][3]=[0,0,0]
points[0][4]=[[[0,0,-1]],grave_F]
points[0][5]=[[1,1,1,points],mut_F]#gives and sends the whole thing back,
points[0][6]=[[2,1,1,points],mut_F]
points[0][7]=[[3,1,1,points],mut_F]
points[0][8]=[[4,1,1,points],mut_F]


points[1]=[""]*8
points[1][0]=[1]
points[1][1]=[0,1,0,[0.1,0,1,0],pos_dis1_F]#wholething_and_goes_to_and_replaced_by_expledis_f
points[1][2]=[0,0,0]
points[1][3]=[0,0,0]
points[1][4]=[[[0,0,-1]],grave_F]
points[1][5]=[[0,1,1,points],mut_F]
points[1][6]=[[2,1,1,points],mut_F]
points[1][7]=[[3,1,1,points],mut_F]




points[2]=[""]*8
points[2][0]=[1]
points[2][1]=[1,0,0,[0.1,1,0,0],pos_dis1_F]#wholething_and_goes_to_and_replaced_by_expledis_f
points[2][2]=[0,0,0]
points[2][3]=[0,0,0]
points[2][4]=[[[0,0,-1]],grave_F]
points[2][5]=[[0,1,1,points],mut_F]
points[2][6]=[[1,1,1,points],mut_F]
points[2][7]=[[3,1,1,points],mut_F]



points[3]=[""]*8
points[3][0]=[1]
points[3][1]=[1,1,0,[0.1,1,1,0],pos_dis1_F]#wholething_and_goes_to_and_replaced_by_expledis_f
points[3][2]=[0,0,0]
points[3][3]=[0,0,0]
points[3][4]=[[[0,0,-1]],grave_F]
points[3][5]=[[0,1,1,points],mut_F]
points[3][6]=[[1,1,1,points],mut_F]
points[3][7]=[[2,1,1,points],mut_F]


points[4]=[""]*12
points[4][0]=[1]
points[4][1]=[0,0,1]#wholething_and_goes_to_and_replaced_by_expledis_f
points[4][2]=[0,0,0]
points[4][3]=[0,0,0]
points[4][4]=[[[0,0,-1]],grave_F]
points[4][5]=[[0,0.25,1,points],mut_F]
points[4][6]=[[1,0.25,1,points],mut_F]
points[4][7]=[[2,0.25,1,points],mut_F]
points[4][8]=[[3,0.25,1,points],mut_F]
points[4][9]=[[5,0.25,1,points],mut_F]
points[4][10]=[[6,0.25,1,points],mut_F]
points[4][11]=[[7,0.25,1,points],mut_F]


points[5]=[""]*12
points[5][0]=[1]
points[5][1]=[0,1,1]#wholething_and_goes_to_and_replaced_by_expledis_f
points[5][2]=[0,0,0]
points[5][3]=[0,0,0]
points[5][4]=[[[0,0,-1]],grave_F]
points[5][5]=[[1,0.25,1,points],mut_F]
points[5][6]=[[0,0.25,1,points],mut_F]
points[5][7]=[[3,0.25,1,points],mut_F]
points[5][8]=[[2,0.25,1,points],mut_F]

points[5][9]=[[4,0.25,1,points],mut_F]

points[5][10]=[[7,0.25,1,points],mut_F]

points[5][11]=[[6,0.25,1,points],mut_F]

points[6]=[""]*12
points[6][0]=[1]
points[6][1]=[1,0,1]#wholething_and_goes_to_and_replaced_by_expledis_f
points[6][2]=[0,0,0]
points[6][3]=[0,0,0]
points[6][4]=[[[0,0,-1]],grave_F]
points[6][5]=[[2,0.25,1,points],mut_F]
points[6][6]=[[0,0.25,1,points],mut_F]
points[6][7]=[[1,0.25,1,points],mut_F]
points[6][8]=[[3,0.25,1,points],mut_F]

points[6][9]=[[7,0.25,1,points],mut_F]
points[6][10]=[[4,0.25,1,points],mut_F]
points[6][11]=[[5,0.25,1,points],mut_F]


points[7]=[""]*12
points[7][0]=[1]
points[7][1]=[1,1,1]#wholething_and_goes_to_and_replaced_by_expledis_f
points[7][2]=[0,0,0]
points[7][3]=[0,0,0]
points[7][4]=[[[0,0,-1]],grave_F]
points[7][5]=[[3,0.25,1,points],mut_F]
points[7][6]=[[2,0.25,1,points],mut_F]
points[7][7]=[[1,0.25,1,points],mut_F]
points[7][8]=[[0,0.25,1,points],mut_F]

points[7][9]=[[5,0.25,1,points],mut_F]
points[7][10]=[[6,0.25,1,points],mut_F]
points[7][11]=[[2,0.25,1,points],mut_F]


conectionlist.append([0,2,[1,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([0,3,[1,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([0,4,[1,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([0,5,[1,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([0,6,[1,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([0,7,[1,1],coler_F,[0.01,2],scailcon_F])

conectionlist.append([1,2,[1,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([1,3,[1,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([1,4,[1,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([1,5,[1,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([1,6,[1,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([1,7,[1,1],coler_F,[0.01,2],scailcon_F])

conectionlist.append([2,3,[1,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([2,4,[1,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([2,5,[1,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([2,6,[1,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([2,7,[1,1],coler_F,[0.01,2],scailcon_F])

conectionlist.append([3,4,[1,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([3,5,[1,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([3,6,[1,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([3,7,[1,1],coler_F,[0.01,2],scailcon_F])


conectionlist.append([4,5,[0.5,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([4,6,[0.5,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([4,7,[0.5,1],coler_F,[0.01,2],scailcon_F])

conectionlist.append([5,6,[0.5,1],coler_F,[0.01,2],scailcon_F])
conectionlist.append([5,7,[0.5,1],coler_F,[0.01,2],scailcon_F])

conectionlist.append([6,7,[0.5,1],coler_F,[0.01,2],scailcon_F])


velocityvecaddlist=[""]*5
velocityvecaddlist[0]=0
velocityvecaddlist[1]=1
velocityvecaddlist[2]=2
velocityvecaddlist[3]=3
velocityvecaddlist[4]=4


forcevecaddlist=[""]*5
forcevecaddlist[0]=0
forcevecaddlist[1]=1
forcevecaddlist[2]=2
forcevecaddlist[3]=3
forcevecaddlist[4]=4
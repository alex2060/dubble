# importing the numpy
import numpy as np

# R is the radius of the Earth
R = 3960
# g is the gravitational constant put into mi/s^2 since everything is in miles
g = 32/5280

# initial velocity, also velocity at final exhaust of fuel, mi/s
v = 6
# initial height above Earth, also the height at final exhaust of fuel, mi
y = 200

# step size in Euler's
h = .1
# how many steps to do
n = 1000000

# definition of f(x,y) in Euler's
def velwrtdist(v,y):
    return -(g*R**2)/(v*(y+R)**2)

# initializing value of i
i = 0
# while loop that performs Euler's
# output is two columns, left column is height, right column is velocity
pos=[]
vel=[]

while i < n:
	if i%1000==0:
		pos.append(y)
		vel.append(v)
		print(y,v)
	v = v + abs(v)/v*h*velwrtdist(v,y)
	y = y + h*abs(v)/v
	i = i + 1
	if y<=0:
		break

add=""
add=add+"o,rocket,stl3.stl\n"
print(pos[0])
for x in range(len(pos)):
	add=add+"l,rocket,"+str(pos[x]/1000)+",0,0,"+str(10*x)+"\n"
	add=add+"arw,vel,"+str(pos[x]/1000+vel[x])+",0,0,"+str(pos[x]/1000)+",0,0,ves.stl,"+str(10*x)+"\n"




file = open("All.txt", "w")
file.write(add)
file.close()



import math
g=10
l1=10
l2=10
m1=1
m2=1

o1p=-0.6
o2p=0.6
o1v=0
o2v=0


def thata1change(g,l1,l2,m1,m2,o1p,o2p):
	p1=-g*(2*m1 + m2)*math.sin(o1p)
	p2=-m2*g*math.sin(o1p-2*o2p)
	p3=-2*math.sin(o1p-o2p)*m2*(o2v**2*l2 + o1v**2*l1*math.cos(o1p-o2p))
	d1=l1*(2*m1 + m2 - m2*math.cos(2*o1p-2*o2p))

	return (p1+p2+p3)/d1

def thata2change(g,l1,l2,m1,m2,o1p,o2p):
	p1=	2*math.sin(o1p-o2p)*(o1v**2*l1*(m1 + m2) + g*(m1 + m2)*math.cos(o1p) + o2v**2*l2*m2*math.cos(o1p-o2p))
	d1=l2*(2*m1 + m2-m2*math.cos(2*o1p-2*o2p))

	return (p1)/d1

number=500000
time=0.00001

thata1=[o1p]
thata2=[o2p]


for x in range(number):
	o1v=o1v+thata1change(g,l1,l2,m1,m2,o1p,o2p)*time
	o2v=o2v+thata2change(g,l1,l2,m1,m2,o1p,o2p)*time
	o2p=o2p+o2v*time
	o1p=o1p+o1v*time
	if x%300==0:
		thata1.append(o1p)
		thata2.append(o2p)

print(thata2)
print(thata1)
add=""

add=add+"o,obj1,stl3n.stl\n"
add=add+"o,obj2,stl3n.stl\n"
add=add+"o,lin1,vesn.stl\n"
add=add+"o,lin2,vesn.stl\n"
add=add+"c,lin2,0,0,0,1\n"
add=add+"c,lin1,0,0,0,1\n"
scail=0.1
for x in range(len(thata1)):
	loc1y=str(math.sin(thata1[x])*l1)
	loc1x=str(math.cos(thata1[x])*l1)
	loc2y=str(float(loc1y)+math.sin(thata2[x])*l2)
	loc2x=str(float(loc1x)+math.cos(thata2[x])*l2)

	add+="l,obj1,"+loc1x+","+loc1y+","+str(0)+","+str(x)+"\n"
	add+="l,obj2,"+loc2x+","+loc2y+","+str(0)+","+str(x)+"\n"
	add+="arw,lin1,0,0,"+str(0)+","+loc1x+","+loc1y+","+str(0)+",vesn.stl,"+str(x)+"\n"
	add+="arw,lin2,"+loc2x+","+loc2y+","+str(0)+","+loc1x+","+loc1y+","+str(0)+",vesn.stl,"+str(x)+"\n"
file = open("All.txt", "w")
file.write(add)
file.close()









import math
g=10
l1=10
l2=10
m1=1
m2=1

o1p=-0.6
o2p=0.6
o1v=0
o2v=0


def thata1change(g,l1,l2,m1,m2,o1p,o2p):
	p1=-g*(2*m1 + m2)*math.sin(o1p)
	p2=-m2*g*math.sin(o1p-2*o2p)
	p3=-2*math.sin(o1p-o2p)*m2*(o2v**2*l2 + o1v**2*l1*math.cos(o1p-o2p))
	d1=l1*(2*m1 + m2 - m2*math.cos(2*o1p-2*o2p))

	return (p1+p2+p3)/d1

def thata2change(g,l1,l2,m1,m2,o1p,o2p):
	p1=	2*math.sin(o1p-o2p)*(o1v**2*l1*(m1 + m2) + g*(m1 + m2)*math.cos(o1p) + o2v**2*l2*m2*math.cos(o1p-o2p))
	d1=l2*(2*m1 + m2-m2*math.cos(2*o1p-2*o2p))

	return (p1)/d1

number=100000
time=0.00005

thata1=[o1p]
thata2=[o2p]


for x in range(number):
	o1v=o1v+thata1change(g,l1,l2,m1,m2,o1p,o2p)*time
	o2v=o2v+thata2change(g,l1,l2,m1,m2,o1p,o2p)*time
	o2p=o2p+o2v*time
	o1p=o1p+o1v*time
	if x%300==0:
		thata1.append(o1p)
		thata2.append(o2p)

print(thata2)
print(thata1)
add=[""]

mad=[""]
#len(thata2)
scail=0.04
at=0
add[at]+="apn,/Users/alex/Desktop/ball.blend/Material/,steelthing\n"
numbermax=50
number=0
framper=2
for x in range(len(thata2)):
	loc1y=str(math.sin(thata1[x])*l1)
	loc1x=str(math.cos(thata1[x])*l1)
	loc2y=str(float(loc1y)+math.sin(thata2[x])*l2)
	loc2x=str(float(loc1x)+math.cos(thata2[x])*l2)
	add[at]+="o,obja1"+str(x)+",ball2.stl\n"
	add[at]+="o,objb2"+str(x)+",ball2.stl\n"
	add[at]+="col,obja1"+str(x)+",steelthing\n"
	add[at]+="col,objb2"+str(x)+",steelthing\n"
	
	add[at]+="o,lina1"+str(x)+",string2.stl\n"
	add[at]+="c,lina1"+str(x)+",1,1,1,1\n"
	mad[at]+="o,linb2"+str(x)+",string2.stl\n"
	mad[at]+="c,linb2"+str(x)+",1,1,1,1\n"
	add[at]+="l,obja1"+str(x)+","+str(float(loc1x)+500)+","+loc1y+","+str(x*scail)+",0"+str(framper*x)+"\n"
	add[at]+="l,obja1"+str(x)+","+loc1x+","+loc1y+","+str(x*scail)+","+str(framper*x+1)+"\n"

	add[at]+="l,objb2"+str(x)+",500,0,0,"+str(framper*x)+"\n"
	add[at]+="l,objb2"+str(x)+","+loc2x+","+loc2y+","+str(x*scail)+","+str(framper*x+1)+"\n"

	
	add[at]+="arw,lina1"+str(x)+",0,0,"+str(x*scail)+","+str(float(loc1x))+","+loc1y+","+str(x*scail)+",string2.stl,"+str(framper*x+1)+"\n"

	
	mad[at]+="l,linb2"+str(x)+",500,100,0,"+str(framper*x)+"\n"
	mad[at]+="arw,linb2"+str(x)+","+loc2x+","+loc2y+","+str(x*scail)+","+loc1x+","+loc1y+","+str(x*scail)+",string2.stl,"+str(framper*x+1)+"\n"
	add[at]+="l,lina1"+str(x)+",500,100,0,"+str(framper*x)+"\n"
	number+=1
	if number==numbermax:
		print("go")
		number=0
		at+=1
		add.append("")
		mad.append("")
print(at)
for x in range(len(add)):
	file = open("All"+str(x)+".txt", "w")
	file.write(add[x])
	file.close()

for x in range(len(add)):
	file = open("sall"+str(x)+".txt", "w")
	file.write(mad[x])
	file.close()










import math
g=10
l1=10
l2=10
m1=1
m2=1

o1p=-0.6
o2p=0.6
o1v=0
o2v=0


def thata1change(g,l1,l2,m1,m2,o1p,o2p):
	p1=-g*(2*m1 + m2)*math.sin(o1p)
	p2=-m2*g*math.sin(o1p-2*o2p)
	p3=-2*math.sin(o1p-o2p)*m2*(o2v**2*l2 + o1v**2*l1*math.cos(o1p-o2p))
	d1=l1*(2*m1 + m2 - m2*math.cos(2*o1p-2*o2p))

	return (p1+p2+p3)/d1

def thata2change(g,l1,l2,m1,m2,o1p,o2p):
	p1=	2*math.sin(o1p-o2p)*(o1v**2*l1*(m1 + m2) + g*(m1 + m2)*math.cos(o1p) + o2v**2*l2*m2*math.cos(o1p-o2p))
	d1=l2*(2*m1 + m2-m2*math.cos(2*o1p-2*o2p))

	return (p1)/d1

number=50000
time=0.0001

thata1=[o1p]
thata2=[o2p]


for x in range(number):
	o1v=o1v+thata1change(g,l1,l2,m1,m2,o1p,o2p)*time
	o2v=o2v+thata2change(g,l1,l2,m1,m2,o1p,o2p)*time
	o2p=o2p+o2v*time
	o1p=o1p+o1v*time
	if x%300==0:
		thata1.append(o1p)
		thata2.append(o2p)

print(thata2)
print(thata1)
add=""

scail=0.1
for x in range(len(thata1)):
	loc1y=str(math.sin(thata1[x])*l1)
	loc1x=str(math.cos(thata1[x])*l1)
	loc2y=str(float(loc1y)+math.sin(thata2[x])*l2)
	loc2x=str(float(loc1x)+math.cos(thata2[x])*l2)
	add=add+"o,obj1"+str(x)+",stl3n.stl\n"
	add=add+"o,obj2"+str(x)+",stl3n.stl\n"
	add=add+"o,lin1"+str(x)+",vesn.stl\n"
	add=add+"o,lin2"+str(x)+",vesn.stl\n"
	add=add+"l,obj1"+str(x)+","+loc1x+","+loc1y+","+str(x*scail)+",0\n"
	add=add+"l,obj2"+str(x)+","+loc2x+","+loc2y+","+str(x*scail)+",0\n"
	add=add+"arw,lin1"+str(x)+",0,0,"+str(x*scail)+","+loc1x+","+loc1y+","+str(x*scail)+",vesn.stl,0\n"
	add=add+"arw,lin2"+str(x)+","+loc2x+","+loc2y+","+str(x*scail)+","+loc1x+","+loc1y+","+str(x*scail)+",vesn.stl,0\n"
file = open("All.txt", "w")
file.write(add)
file.close()







